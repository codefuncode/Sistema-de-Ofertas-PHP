UPDATE packes
SET fechas = 03-20-2021
WHERE nombre = 4;

